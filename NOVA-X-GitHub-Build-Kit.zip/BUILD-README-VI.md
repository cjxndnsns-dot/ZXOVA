# NOVA X / ZXOVA — build bằng GitHub Actions trên iPhone

Repo này dùng GitHub Actions chạy trên máy macOS đám mây để biên dịch dự án Xcode. Workflow chỉ tạo **IPA unsigned** để kiểm tra build; nó **chưa được ký** và thông thường không thể cài trực tiếp lên iPhone. Cần chữ ký/phân phối hợp lệ để cài hoặc chia sẻ.

## Cấu trúc
- `ThreeOneOSFive.xcodeproj`: dự án Xcode gốc.
- `ThreeOneOSFive/`: mã nguồn ứng dụng.
- `.github/workflows/build-ios.yml`: workflow build tự động.

## Chạy build
1. Đưa toàn bộ nội dung repo này lên GitHub, giữ nguyên đường dẫn `.github/workflows/build-ios.yml` ở thư mục gốc.
2. Mở tab **Actions** của repo và bật Actions nếu GitHub yêu cầu.
3. Chọn **Build NOVA X iOS (unsigned)** → **Run workflow** → **Run workflow**.
4. Chờ job hoàn tất. Nếu xanh, mở lần chạy đó, kéo xuống **Artifacts**, tải `NOVA-X-build-output`.
5. Nếu lỗi, mở log `xcodebuild.log` trong artifact hoặc log job để xem lỗi biên dịch.

## Quan trọng
- Workflow không ký app, không tạo chứng chỉ và không đảm bảo app cài được.
- Không đưa chứng chỉ, mật khẩu hay khóa riêng vào repo.
- Chỉ dùng các tính năng sửa đổi thiết bị/patch trên thiết bị và dữ liệu bạn có quyền kiểm soát. Workflow không được cấu hình để né bảo vệ của game hoặc ứng dụng bên thứ ba.
