import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @AppStorage(FeatureVisibility.developerModeStorageKey)
    private var developerModeEnabled = false
    @State private var tabNavigation: AppTabNavigationState
    @State private var showSettings = false
    @State private var showLogs = false

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-new-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-sources-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-installed-tab")
                    || arguments.contains("--simulate-patch-tab")
                    || arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-files-tab") {
            initialTab = 4
        } else if arguments.contains("--simulate-search-tab") {
            initialTab = 5
        } else {
            initialTab = 0
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
        _showSettings = State(
            initialValue: arguments.contains("--simulate-settings")
        )
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.installed.rawValue) }
        }
        .onChange(of: developerModeEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showLogs) { LogView() }
        .patchStorePresentation(patchStore)
        .repositoryStorePresentation(repositoryStore, patchStore: patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("3105")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            ZxovaDashboardView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .new:
            RepositoryNewView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .sources:
            RepositorySourcesView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .installed:
            PatchProjectsView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession,
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        case .search:
            RepositorySearchView(
                onOpenSettings: openSettings,
                onOpenLogs: openLogs
            )
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(developerModeEnabled: developerModeActive)
    }

    private var developerModeActive: Bool {
#if targetEnvironment(simulator)
        developerModeEnabled
            || ProcessInfo.processInfo.arguments.contains("--simulate-developer-mode")
            || ProcessInfo.processInfo.arguments.contains("--simulate-files-tab")
#else
        developerModeEnabled
#endif
    }

    private var selectedVisibleSection: AppSection {
        let selected = AppSection(rawValue: tabNavigation.selectedTab)
        return selected.flatMap {
            featureVisibility.isVisible($0) ? $0 : nil
        } ?? .home
    }

    private func openSettings() {
        showSettings = true
    }

    private func openLogs() {
        showLogs = true
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .new: return "tab.new"
        case .sources: return "tab.sources"
        case .installed: return "tab.installed"
        case .files: return "tab.files"
        case .search: return "tab.search"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .new: return "clock.fill"
        case .sources: return "shippingbox.fill"
        case .installed: return "tray.full.fill"
        case .files: return "folder.fill"
        case .search: return "magnifyingglass"
        }
    }
}


// ZXOVA dashboard inspired by the supplied “GIAO DIỆN CHO APP.html”.
// These switches control this screen's presentation state only; they do not
// install a DNS profile or activate external/game modules.
private struct ZxovaDashboardView: View {
    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    @State private var selectedPanel = 0
    @State private var activeMenu: String? = nil
    @State private var dnsEnabled = false
    @State private var logs: [String] = [
        "ZXOVA Control Panel v3.0",
        "Tabs: MENU / DNS",
        "System ready"
    ]

    private let purple = Color(red: 0.66, green: 0.32, blue: 0.97)
    private let panel = Color(red: 0.14, green: 0.08, blue: 0.25)
    private let border = Color(red: 0.32, green: 0.18, blue: 0.51)

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.10, green: 0.05, blue: 0.18), Color(red: 0.17, green: 0.08, blue: 0.31), .black],
                startPoint: .topLeading, endPoint: .bottomTrailing
            ).ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    header
                    tabPicker
                    if selectedPanel == 0 { menuPanel } else { dnsPanel }
                    logPanel
                    Text("ZXOVA • CONTROL PANEL")
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.35))
                        .padding(.top, 2)
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)
                .padding(.bottom, 24)
                .frame(maxWidth: 560)
                .frame(maxWidth: .infinity)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 15).fill(purple.opacity(0.22))
                RoundedRectangle(cornerRadius: 15).stroke(purple.opacity(0.8), lineWidth: 1)
                Image(systemName: "sparkles.tv.fill")
                    .font(.system(size: 23, weight: .bold))
                    .foregroundStyle(Color(red: 0.86, green: 0.68, blue: 1))
                    .shadow(color: purple, radius: 8)
            }
            .frame(width: 54, height: 54)

            VStack(alignment: .leading, spacing: 4) {
                Text("ZXOVA").font(.system(size: 25, weight: .black, design: .rounded)).tracking(2)
                    .foregroundStyle(.white)
                Text("ZIN ZXOVA  •  CONTROL PANEL")
                    .font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(1.1)
                    .foregroundStyle(Color(red: 0.80, green: 0.62, blue: 1))
            }
            Spacer(minLength: 2)
            Button(action: onOpenLogs) {
                Image(systemName: "terminal.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 40)
                    .background(panel, in: RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(border, lineWidth: 1))
            }
            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 40)
                    .background(panel, in: RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(border, lineWidth: 1))
            }
        }
        .padding(14)
        .background(panel.opacity(0.94), in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(border, lineWidth: 1))
        .shadow(color: purple.opacity(0.16), radius: 18)
    }

    private var tabPicker: some View {
        HStack(spacing: 5) {
            tabButton("MENU", icon: "slider.horizontal.3", index: 0)
            tabButton("DNS", icon: "network", index: 1)
        }
        .padding(5)
        .background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(border.opacity(0.8), lineWidth: 1))
    }

    private func tabButton(_ title: String, icon: String, index: Int) -> some View {
        Button {
            withAnimation(.easeInOut(duration: 0.18)) { selectedPanel = index }
            addLog("Tab switched → \(title)")
        } label: {
            HStack(spacing: 8) {
                Image(systemName: icon)
                Text(title).tracking(1.2)
            }
            .font(.system(size: 12, weight: .heavy, design: .rounded))
            .foregroundStyle(selectedPanel == index ? .white : Color.white.opacity(0.55))
            .frame(maxWidth: .infinity).padding(.vertical, 13)
            .background {
                if selectedPanel == index {
                    RoundedRectangle(cornerRadius: 10).fill(purple.gradient)
                        .shadow(color: purple.opacity(0.4), radius: 8, y: 2)
                }
            }
        }.buttonStyle(.plain)
    }

    private var menuPanel: some View {
        VStack(spacing: 12) {
            sectionHeading("MENU MODULES", subtitle: "Chọn một module để bật")
            moduleCard(code: "FFTH", title: "MENU FFTH", description: "Module status", isOn: activeMenu == "FFTH") {
                activeMenu = activeMenu == "FFTH" ? nil : "FFTH"
                addLog("MENU FFTH → \(activeMenu == "FFTH" ? "ENABLED" : "DISABLED")")
            }
            moduleCard(code: "FFM", title: "MENU FFM", description: "Module status", isOn: activeMenu == "FFM") {
                activeMenu = activeMenu == "FFM" ? nil : "FFM"
                addLog("MENU FFM → \(activeMenu == "FFM" ? "ENABLED" : "DISABLED")")
            }
            HStack(spacing: 10) {
                statCard(label: "ACTIVE", value: activeMenu == nil ? "0" : "1", icon: "bolt.fill")
                statCard(label: "UPTIME", value: "00:00", icon: "clock.fill")
                statCard(label: "EVENTS", value: "\(logs.count)", icon: "waveform.path")
            }
            footerRow(label: "MENU STATE", value: activeMenu ?? "IDLE", isActive: activeMenu != nil)
        }
        .padding(14)
        .background(panel.opacity(0.84), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(border, lineWidth: 1))
    }

    private var dnsPanel: some View {
        VStack(spacing: 12) {
            sectionHeading("DNS BOOSTER", subtitle: "Network panel")
            moduleCard(code: "DNS", title: "DNS BOOSTER", description: "Low-ping DNS resolver", isOn: dnsEnabled) {
                dnsEnabled.toggle()
                addLog("DNS BOOSTER → \(dnsEnabled ? "ENABLED" : "DISABLED")")
            }
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 8) {
                    Image(systemName: "list.number").foregroundStyle(purple)
                    Text("HƯỚNG DẪN SỬ DỤNG").font(.system(size: 11, weight: .heavy)).tracking(0.8)
                }
                instructionRow("1", "Vào game")
                instructionRow("2", "Ở sảnh bật DNS lên")
                instructionRow("3", "Vào trận")
                instructionRow("4", "Thoát ra bật Menu")
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 14))
            HStack(spacing: 10) {
                statCard(label: "STATUS", value: dnsEnabled ? "ACTIVE" : "IDLE", icon: "circle.fill")
                statCard(label: "LATENCY", value: "--", icon: "speedometer")
                statCard(label: "SERVER", value: "1.1.1.1", icon: "server.rack")
            }
            footerRow(label: "DNS STATE", value: dnsEnabled ? "ENABLED" : "DISABLED", isActive: dnsEnabled)
            Text("Ghi chú: công tắc hiện chỉ đổi trạng thái giao diện; chưa cấu hình DNS thật trên thiết bị.")
                .font(.system(size: 10)).foregroundStyle(.white.opacity(0.45))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(14)
        .background(panel.opacity(0.84), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(border, lineWidth: 1))
    }

    private var logPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("SYSTEM LOG", systemImage: "terminal")
                    .font(.system(size: 11, weight: .heavy, design: .monospaced)).tracking(0.8)
                    .foregroundStyle(Color(red: 0.83, green: 0.69, blue: 1))
                Spacer()
                Button("CLEAR") {
                    logs = []
                    addLog("Log cleared by user")
                }
                .font(.system(size: 10, weight: .heavy, design: .monospaced))
                .foregroundStyle(purple)
            }
            ForEach(Array(logs.suffix(5)), id: \.self) { entry in
                HStack(alignment: .top, spacing: 8) {
                    Text("›").foregroundStyle(purple).fontWeight(.black)
                    Text(entry).foregroundStyle(.white.opacity(0.72))
                }.font(.system(size: 10, design: .monospaced))
            }
            if logs.isEmpty { Text("No events").font(.system(size: 10, design: .monospaced)).foregroundStyle(.white.opacity(0.4)) }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(border.opacity(0.7), lineWidth: 1))
    }

    private func sectionHeading(_ title: String, subtitle: String) -> some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 12, weight: .black, design: .rounded)).tracking(1)
                    .foregroundStyle(.white)
                Text(subtitle).font(.system(size: 10)).foregroundStyle(.white.opacity(0.48))
            }
            Spacer()
            Circle().fill(Color.green).frame(width: 6, height: 6)
                .shadow(color: .green.opacity(0.8), radius: 5)
            Text("READY").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.green)
        }.padding(.bottom, 2)
    }

    private func moduleCard(code: String, title: String, description: String, isOn: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11).fill(isOn ? purple.opacity(0.26) : Color.white.opacity(0.045))
                    RoundedRectangle(cornerRadius: 11).stroke(isOn ? purple : border.opacity(0.8), lineWidth: 1)
                    Text(code).font(.system(size: code.count > 3 ? 10 : 12, weight: .black, design: .rounded))
                        .foregroundStyle(isOn ? Color(red: 0.88, green: 0.72, blue: 1) : .white.opacity(0.65))
                }.frame(width: 48, height: 48)
                VStack(alignment: .leading, spacing: 5) {
                    Text(title).font(.system(size: 12, weight: .heavy)).foregroundStyle(.white)
                    HStack(spacing: 5) {
                        Circle().fill(isOn ? Color.green : Color.gray).frame(width: 5, height: 5)
                        Text(isOn ? "ON" : "OFF").font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(isOn ? .green : .white.opacity(0.42))
                    }
                    Text(description).font(.system(size: 10)).foregroundStyle(.white.opacity(0.42))
                }
                Spacer(minLength: 4)
                ZStack(alignment: isOn ? .trailing : .leading) {
                    Capsule().fill(isOn ? purple : Color.white.opacity(0.15)).frame(width: 42, height: 24)
                    Circle().fill(.white).frame(width: 18, height: 18).padding(3)
                }
            }
            .padding(12)
            .background(isOn ? purple.opacity(0.12) : Color.black.opacity(0.16), in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(isOn ? purple.opacity(0.8) : border.opacity(0.75), lineWidth: 1))
        }.buttonStyle(.plain)
    }

    private func statCard(label: String, value: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Image(systemName: icon).font(.system(size: 11, weight: .bold)).foregroundStyle(purple)
            Text(label).font(.system(size: 8, weight: .bold, design: .monospaced)).tracking(0.4).foregroundStyle(.white.opacity(0.45))
            Text(value).font(.system(size: value.count > 6 ? 10 : 14, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(11)
        .background(Color.black.opacity(0.2), in: RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(border.opacity(0.65), lineWidth: 1))
    }

    private func footerRow(label: String, value: String, isActive: Bool) -> some View {
        HStack {
            Text(label).foregroundStyle(.white.opacity(0.45))
            Spacer()
            Text(value).foregroundStyle(isActive ? .green : Color(red: 0.77, green: 0.65, blue: 0.91))
        }
        .font(.system(size: 9, weight: .bold, design: .monospaced))
        .padding(.top, 4)
    }

    private func instructionRow(_ number: String, _ text: String) -> some View {
        HStack(spacing: 10) {
            Text(number).font(.system(size: 10, weight: .black, design: .monospaced))
                .foregroundStyle(.white).frame(width: 22, height: 22)
                .background(purple.opacity(0.35), in: RoundedRectangle(cornerRadius: 7))
            Text(text).font(.system(size: 11)).foregroundStyle(.white.opacity(0.75))
        }
    }

    private func addLog(_ message: String) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        logs.append("[\(formatter.string(from: Date()))] \(message)")
        if logs.count > 30 { logs.removeFirst(logs.count - 30) }
    }
}
